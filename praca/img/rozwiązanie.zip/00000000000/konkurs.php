<?php 
$connection = mysqli_connect("127.0.0.1", "root", "", "konkurs");
if ($connection == false) {
    echo "Nie można połączyć się z bazą danych";
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WOLONTARIAT SZKOLNY</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>KONKURS - WOLONTARIAT SZKOLNY</h1>
    </header>
    <section class="left">
        <h3>Konkursowe nagrody</h3>
        <button onclick="window.location.href='konkurs.php'">Losuj nowe nagrody</button>
        <table>
            <thead>
                <tr>
                    <th>Nr</th>
                    <th>Nazwa</th>
                    <th>Opis</th>
                    <th>Wartość</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $index = 1;
                $query = mysqli_query($connection, "SELECT nazwa, opis, cena FROM nagrody ORDER BY RAND() LIMIT 5;");
                while ($result = mysqli_fetch_array($query)) {
                    echo "<tr>";
                    echo "<td>".$index."</td>";
                    echo "<td>".$result['nazwa']."</td>";
                    echo "<td>".$result['opis']."</td>";
                    echo "<td>".$result['cena']."</td>";
                    echo "</tr>";
                    $index += 1;
                }
                ?>
                <!-- Skrypt -->
            </tbody>
        </table>
    </section>
    <section class="right">
        <img src="puchar.png" alt="Puchar dla wolontariusza">
        <h4>Polecane linki</h4>
        <ul>
            <li><a href="kw1.png">Kwerenda1</a></li>
            <li><a href="kw2.png">Kwerenda2</a></li>
            <li><a href="kw3.png">Kwerenda3</a></li>
            <li><a href="kw4.png">Kwerenda4</a></li>
        </ul>
    </section>
    <footer>
        <p>Numer zdającego: 00000000000</p>
    </footer>
</body>
</html>
<?php
mysqli_close($connection);
?>